﻿using HCOAPP.Controllers;
using HCOAPP.DataAccessLayer;
using HCOAPP.Model;
using Moq;
using NUnit.Framework;

namespace UnitTests
{
    public class HcoDLTest
    {
        
        private readonly IHcoDL _hcoDL;
        private MockRepository mockRepository;
        private Mock<IHcoDL> mockHcoRepo;

        [SetUp]
        public void Setup()
        {
            //hcodl = new HcoDL();
            this.mockRepository = new MockRepository(MockBehavior.Strict);
            this.mockHcoRepo = this.mockRepository.Create<IHcoDL>();
        }

        private HCOController Create()
        {
            return new HCOController(this.mockHcoRepo.Object);
        }

        [Test]
        public void GetAll_ExpectedBehaviour()
        {
            var hcoController = Create();
            InsertRecordRequest info = new InsertRecordRequest()
            {
                Id = "",
                OrgName = "TestOrganization",
                Address = "ABCD,1234",
                State = "West Bengal",
                Country = "India",
                City = "Kolkata",
                zipCode = 700040,
                EmailId = "pri@test.com",
                Website = "https://abcd.com",
                PrimaryContact = "Skgf",
                PrimaryContactMobile = "9876543210",
                SecondaryContact = "Lkhjg",
                SecondaryContactMobile = "9876543210",
                Programs = "abcd",
                Status = ""
            };
            mockHcoRepo.Setup(i => i.GetAllRecord());
            var result = hcoController.GetAllRecord();
            var final = result;
            Assert.True(true);
            this.mockHcoRepo.Verify(i => i.GetAllRecord(), Times.Once());
            this.mockRepository.VerifyAll();
        }

        [Test]
        public void GetAllRecord_Works()
        {
            //Arrange

            HCOController hco = new HCOController(_hcoDL);
            //Act
            var record = hco.GetAllRecord();
            //Assert
            Assert.IsNotNull(record);
        }
        [Test]
        public void GetRecordById_Works()
        {
            HcoDL hco2 = new HcoDL();
            var record2 = hco2.GetRecordById("1");
            Assert.IsNull(record2.Result.data);
        }
    }
}
