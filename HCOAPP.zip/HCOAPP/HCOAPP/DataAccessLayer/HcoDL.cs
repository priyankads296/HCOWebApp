﻿using HCOAPP.Model;
using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HCOAPP.DataAccessLayer
{
    public class HcoDL: IHcoDL
    {
        private readonly IConfiguration _configuration;
        private readonly MongoClient _mongoClient;
        private readonly IMongoCollection<InsertRecordRequest> _userCollection;


        public HcoDL()
        {
        }

        public HcoDL(IConfiguration configuration)
        {
            _configuration = configuration;
            _mongoClient = new MongoClient(_configuration["DatabaseSettings:ConnectionString"]);
            var _MongoDatabase = _mongoClient.GetDatabase(_configuration["DatabaseSettings:DatabaseName"]);
            _userCollection = _MongoDatabase.GetCollection<InsertRecordRequest>(_configuration["DatabaseSettings:UserCollectionName"]);
            

        }

        public async Task<GetAllRecordResponse> GetAllRecord()
        {
            GetAllRecordResponse response = new GetAllRecordResponse();
            response.IsSuccess = true;
            response.Message = "Data Fetch Successfully";
            try
            {
                response.data = new List<InsertRecordRequest>();
                response.data = await _userCollection.Find(x => true).ToListAsync();
                if(response.data.Count==0)
                {
                    response.Message = "No Record Found";
                }
            }catch(Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Occurs."+ex.Message;
            }
            return response;
        }

        public async Task<GetRecordByIdResponse> GetRecordById(string ID)
        {
            GetRecordByIdResponse response = new GetRecordByIdResponse();
            response.IsSuccess = true;
            response.Message= "Data Fetch Successfully By Id";
            try
            {
                response.data = await _userCollection.Find(x => x.Id == ID).FirstOrDefaultAsync();
                if(response.data==null)
                {
                    response.Message = "Invalid Id!\n Please Enter Valid Id. ";
                }
            }catch(Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Occurs : " + ex.Message;

            }
            return response;
        }

        public async Task<InsertRecordResponse> InsertRecord(InsertRecordRequest request)
        {
           
            InsertRecordResponse res = new InsertRecordResponse();
            res.IsSuccess = true;
            res.Message = "200 OK: Data Successfully Inserted";
            try
            {
               
                request.CreatedDate = DateTime.Now.ToString();
                request.UpdatedDate = string.Empty;
                request.Status = "Submitted";
                
                await _userCollection.InsertOneAsync(request);
               
            }catch(Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;

            }
            return res;
        }

        public async Task<UpdateRecordByIdResponse> UpdateRecordById(InsertRecordRequest request)
        {
            UpdateRecordByIdResponse res = new UpdateRecordByIdResponse();
            res.IsSuccess = true;
            res.Message = "Update Record Successfully By Id.";
            try
            {
                GetRecordByIdResponse res1 = await GetRecordById(request.Id);
                request.CreatedDate = res1.data.CreatedDate;
                request.UpdatedDate = DateTime.Now.ToString();

                var result = await _userCollection.ReplaceOneAsync(x => x.Id== request.Id,request);
                if(!result.IsAcknowledged)
                {
                    res.Message = "Input Id Not Found / Updation Not Occurs";
                }
            }
            catch (Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;

            }
            return res;
        }

  
        
        public async Task<UpdateStatusResponse> UpdateStatus(UpdateStatusRequest request)
        {
            UpdateStatusResponse res = new UpdateStatusResponse();
            res.IsSuccess = true;
            res.Message = "Status Updated.";
            try
            {
                GetRecordByIdResponse res1 = await GetRecordById(request.Id);
                var filter = new BsonDocument().Add("Status", request.Status).Add("UpdatedDate", DateTime.Now.ToString());

                var UpdatedDate = new BsonDocument("$set", filter);
                var result = await _userCollection.UpdateOneAsync(x => x.Id == request.Id, UpdatedDate);

                if (!result.IsAcknowledged)
                {
                    res.Message = "Input Id Not Found / Updation Not Occurs";
                }
            }
            catch(Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs."+ex.Message;
            }
            return res;
        }
    }
}
