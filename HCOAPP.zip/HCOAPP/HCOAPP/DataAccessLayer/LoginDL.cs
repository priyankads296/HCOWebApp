﻿using HCOAPP.Model;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
/*using Microsoft.AspNetCore.Http;*/
using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
namespace HCOAPP.DataAccessLayer
{
    public class LoginDL : ILoginDL
    {

        private readonly IConfiguration _configuration;
        private readonly MongoClient _mongoClient;
        private readonly IMongoCollection<RegisterRequest> _loginCollection;

        public LoginDL(IConfiguration configuration)
        {
            _configuration = configuration;
            _mongoClient = new MongoClient(_configuration["DatabaseSettings:ConnectionString"]);
            var _MongoDatabase = _mongoClient.GetDatabase(_configuration["DatabaseSettings:DatabaseName"]);
            _loginCollection = _MongoDatabase.GetCollection<RegisterRequest>(_configuration["DatabaseSettings:LoginCollectionName"]);
        }

        //public async Task<RegisterResponse> Login(string username,string password)
        public async Task<RegisterResponse> Login(LoginRequest req)
        {
            RegisterResponse response = new RegisterResponse();
            response.IsSuccess = true;
            response.Message = "Data fetched Successfully";
            try
            {
                EncryptDecrypt ed = new EncryptDecrypt();

                var user = await _loginCollection.Find(x => x.Username == req.username && x.Role == req.role).FirstOrDefaultAsync();
                if (user != null)
                {
                    bool isValid = (user.Username == req.username && ed.DecryptPassword(user.Password) == req.password);
                    if (isValid)
                    {
                        
                        response.data = user;
                    }
                        

                }

                if (response.data == null)
                {

                    response.Message = "Invalid Credentials!\n Please Enter Valid Credentials. ";
                }
               
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Occurs : " + ex.Message;

            }
            return response;
        }

        public async Task<RegisterResponse> SignUp(RegisterRequest request)
        {

            RegisterResponse res = new RegisterResponse();
            res.IsSuccess = true;
            res.Message = "200 OK: Data Successfully Inserted";
            try
            {
                EncryptDecrypt ed = new EncryptDecrypt();
                request.Password=ed.EncryptPassword(request.Password);
                await _loginCollection.InsertOneAsync(request);
                res.data = request;
              
               
            }
            catch (Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;

            }
            return res;
        }
    }
}
