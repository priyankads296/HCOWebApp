﻿using HCOAPP.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HCOAPP.DataAccessLayer
{
    public interface ILoginDL
    {
        /* public Task<LoginResponse> InsertUser(LoginRequest request);
         public Task<GetAllLoginResponse> GetUsers(LoginRequest request);*/

        public Task<RegisterResponse> Login(LoginRequest req);
        public Task<RegisterResponse> SignUp(RegisterRequest req);
    }
}
