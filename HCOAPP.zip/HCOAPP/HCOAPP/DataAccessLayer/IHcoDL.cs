﻿using HCOAPP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HCOAPP.DataAccessLayer
{
    public interface IHcoDL
    {
        public Task<InsertRecordResponse> InsertRecord(InsertRecordRequest request);
        public Task<GetAllRecordResponse> GetAllRecord();
        public Task<GetRecordByIdResponse> GetRecordById(string ID);
        public Task<UpdateRecordByIdResponse> UpdateRecordById(InsertRecordRequest request);
        public Task<UpdateStatusResponse> UpdateStatus(UpdateStatusRequest request);
    }
}
