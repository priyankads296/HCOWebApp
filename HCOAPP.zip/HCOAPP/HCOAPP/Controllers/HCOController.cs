﻿using HCOAPP.DataAccessLayer;
using HCOAPP.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HCOAPP.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class HCOController : ControllerBase
    {
        private readonly IHcoDL _hcoDL;

        public HCOController(IHcoDL hcoDL)
        {
            _hcoDL = hcoDL;
        }

      
       [HttpPost]
        public async Task<IActionResult> InsertRecord(InsertRecordRequest req)
        {
            InsertRecordResponse res = new InsertRecordResponse();              //connection established between controller and data access layer
            try
            {
                res = await _hcoDL.InsertRecord(req);
            }catch(Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;
            }
            return Ok(res);
        }

       

        [HttpGet]
        public async Task<IActionResult> GetAllRecord()
        {
            GetAllRecordResponse res = new GetAllRecordResponse();              //connection established between controller and data access layer
            try
            {
                res = await _hcoDL.GetAllRecord();
            }
            catch (Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;
            }
            return Ok(res);
        }

        [HttpGet]

        public async Task<IActionResult> GetRecordById([FromQuery]string ID)
        {
            GetRecordByIdResponse res = new GetRecordByIdResponse();              //connection established between controller and data access layer
            try 
            {
                res = await _hcoDL.GetRecordById(ID);
            }
            catch (Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;
            }
            return Ok(res);
        }

        [HttpPut]
 
        public async Task<IActionResult> UpdateRecordById(InsertRecordRequest request)
        {
            UpdateRecordByIdResponse res = new UpdateRecordByIdResponse();              //connection established between controller and data access layer
            try
            {
                res = await _hcoDL.UpdateRecordById(request);
            }
            catch (Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;
            }
            return Ok(res);
        }
        [HttpPut]
        public async Task<IActionResult> UpdateStatus(UpdateStatusRequest request)
        {
            UpdateStatusResponse res = new UpdateStatusResponse();              //connection established between controller and data access layer
            try
            {
                res = await _hcoDL.UpdateStatus(request);
            }
            catch (Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : "
                    + ex.Message;
            }
            return Ok(res);
        }

       
    }
}
