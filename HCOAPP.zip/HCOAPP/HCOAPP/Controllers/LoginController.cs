﻿using HCOAPP.DataAccessLayer;
using HCOAPP.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace HCOAPP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginDL _loginDL;
        public LoginController(ILoginDL loginDL)
        {
            _loginDL = loginDL;
        }

       /* [HttpPost]
        public ActionResult Authenticate([FromBody] LoginRequest userobj)
        {
            LoginResponse res = new LoginResponse();
            res.IsSuccess = true;
            res.Message = "Data fetched Successfully";
            try
            {
                var obj = _loginDL.GetDetails(userobj.username);
                if (obj==null)
                {
                    res.IsSuccess = false;
                    res.Message = "User Is Invalid";
                }
                else if(obj.password!=userobj.password)
                {
                    res.IsSuccess = false;
                    res.Message = "Password is Incorrect";
                }
                else
                {
                    obj.Token = CreateJwt(obj);
                    return Ok(new
                    {
                        Token = obj.Token,
                        isLoggedin = "true",
                        Message = ($"Login Successful, Welcome {obj.username} !!")

                    });
                }
            }
            catch (Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;
            }
            return Ok(res);

        }
       
        private string CreateJwt(LoginRequest obj)
        {
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes("veryverysecret......");
            var identity = new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Role,obj.role),
                new Claim(ClaimTypes.Name,$"{obj.username}")
            });
            var credentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = identity,
                Expires = DateTime.Now.AddDays(1),
                SigningCredentials = credentials
            };

            var token = jwtTokenHandler.CreateToken(tokenDescriptor);
            return jwtTokenHandler.WriteToken(token);
        }
       */
  /*      [HttpPost]
        [Route("Signup")]
        public async Task<IActionResult> SignUp(RegisterRequest req)
        {
            RegisterResponse res = new RegisterResponse();              //connection established between controller and data access layer
            try
            {
                res = await _loginDL.SignUp(req);
            }
            catch (Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;
            }
            return Ok(res);
        }
  */
        [HttpPost]
        [Route("Signup")]
        public async Task<IActionResult> SignUp(RegisterRequest req)
        {
            RegisterResponse res = new RegisterResponse();
            try
            {
               
                res = await _loginDL.SignUp(req);
            }
            catch(Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;
            }
            return Ok(res);
        }

        [HttpPost]
        
        //public async Task<IActionResult> Login([FromQuery]string username,string password)
        public async Task<IActionResult> Login([FromQuery]LoginRequest req)
        {
            RegisterResponse res = new RegisterResponse();              //connection established between controller and data access layer
            try
            {
                res = await _loginDL.Login(req);
            }
            catch (Exception ex)
            {
                res.IsSuccess = false;
                res.Message = "Exception Occurs : " + ex.Message;
            }
            return Ok(res);
        }
    }
}
