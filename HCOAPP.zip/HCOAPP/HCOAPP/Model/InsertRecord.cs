﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HCOAPP.Model
{
    public class InsertRecordRequest
    {
      [BsonId]
       [BsonRepresentation(BsonType.ObjectId)]
        
        
        public string? Id { get; set; }

        public string CreatedDate { get; set; }
        public string UpdatedDate { get; set; }

        [Required]
        public string OrgName { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public string State { get; set; }
        [Required]
        public string Country { get; set; }
        [Required]
        public string City{ get; set; }
        [Required]
        [RegularExpression(@"^(\d{6})$")]
        public int zipCode { get; set; }
        [Required]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string EmailId { get; set; }
        [Required]
        [Url]
        public string Website { get; set; }
        [Required]
        public string PrimaryContact { get; set; }
        [Required]
        [RegularExpression(@"^(\d{10})$")]
        public string PrimaryContactMobile { get; set; }
        [Required]
        public string SecondaryContact { get; set; }
        [Required]
        [RegularExpression(@"^(\d{10})$")]
        public string SecondaryContactMobile { get; set; }
        [Required]
        public string Programs { get; set; }
        
        
        public string Status { get; set; }

  
    }
    public class InsertRecordResponse
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }
}
