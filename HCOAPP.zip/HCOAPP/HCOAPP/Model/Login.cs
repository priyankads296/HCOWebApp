﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HCOAPP.Model
{
    public class LoginRequest
    {

      
        //[Required(ErrorMessage="UserName is required")]
        public string username { get; set; }
        
        //[Required(ErrorMessage = "Password is required")]
        public string password { get; set; }
        public string role { get; set; }
       // public string Token { get; set; }
        public bool IsRemember { get; set; }

    }
    public class LoginResponse
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public LoginRequest data { get; set; }
    }
}
